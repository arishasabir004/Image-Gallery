const galleryItems = document.querySelectorAll(".gallery-item");
const filterButtons = document.querySelectorAll(".filter-btn");

const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");
const caption = document.getElementById("caption");
const closeBtn = document.querySelector(".close");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");

let currentIndex = 0;
let visibleImages = [];

/* -------------------------
   FILTER FUNCTIONALITY
------------------------- */
filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    document.querySelector(".filter-btn.active").classList.remove("active");
    button.classList.add("active");

    const filter = button.getAttribute("data-filter");

    galleryItems.forEach(item => {
      if (filter === "all" || item.classList.contains(filter)) {
        item.classList.remove("hide");
      } else {
        item.classList.add("hide");
      }
    });

    updateVisibleImages();
  });
});

/* -------------------------
   UPDATE VISIBLE IMAGES
------------------------- */
function updateVisibleImages() {
  visibleImages = Array.from(document.querySelectorAll(".gallery-item:not(.hide) img"));
}
updateVisibleImages();

/* -------------------------
   OPEN LIGHTBOX
------------------------- */
galleryItems.forEach(item => {
  const img = item.querySelector("img");
  img.addEventListener("click", () => {
    updateVisibleImages();
    currentIndex = visibleImages.indexOf(img);
    showImage();
    lightbox.style.display = "flex";
  });
});

/* -------------------------
   SHOW IMAGE IN LIGHTBOX
------------------------- */
function showImage() {
  lightboxImg.src = visibleImages[currentIndex].src;
  caption.textContent = visibleImages[currentIndex].alt;
}

/* -------------------------
   NEXT / PREVIOUS
------------------------- */
nextBtn.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % visibleImages.length;
  showImage();
});

prevBtn.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + visibleImages.length) % visibleImages.length;
  showImage();
});

/* -------------------------
   CLOSE LIGHTBOX
------------------------- */
closeBtn.addEventListener("click", () => {
  lightbox.style.display = "none";
});

lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) {
    lightbox.style.display = "none";
  }
});

/* -------------------------
   KEYBOARD SUPPORT
------------------------- */
document.addEventListener("keydown", (e) => {
  if (lightbox.style.display === "flex") {
    if (e.key === "ArrowRight") {
      currentIndex = (currentIndex + 1) % visibleImages.length;
      showImage();
    } else if (e.key === "ArrowLeft") {
      currentIndex = (currentIndex - 1 + visibleImages.length) % visibleImages.length;
      showImage();
    } else if (e.key === "Escape") {
      lightbox.style.display = "none";
    }
  }
});